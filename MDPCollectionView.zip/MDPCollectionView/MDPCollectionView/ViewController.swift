//
//  ViewController.swift
//  MDPCollectionView
//
//  Created by Andre' Coward on 8/6/17.
//  Copyright © 2017 Andre' Coward. All rights reserved.
//

import UIKit
import Alamofire
import Haneke

class ViewController: UIViewController, UICollectionViewDataSource, UICollectionViewDelegate {
    
    @IBOutlet var aCollectionView: UICollectionView!
    var datas: [JSON] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.navigationItem.title = "My Photos"
        
        // manual resize of collectionView layout
        let layout = UICollectionViewFlowLayout()
        layout.sectionInset = UIEdgeInsetsMake(0, 0, 0, 0)
        layout.itemSize = CGSize(width: UIScreen.main.bounds.width/3 - 3, height: UIScreen.main.bounds.width/3 - 3)
        layout.minimumInteritemSpacing = 3
        layout.minimumLineSpacing = 3
        
        aCollectionView.collectionViewLayout = layout
        
        // data request to Instagram api
        Alamofire.request("https://api.instagram.com/v1/users/self/media/recent/?access_token=535497333.4944ed7.f3d070cab84b4aa383c900ef7254c6f6").response { response in
            var jsonObj = JSON(response.data!)
            
            if let data = jsonObj["data"].arrayValue as [JSON]? {
                self.datas = data
                self.aCollectionView.reloadData()
            }
        }
    }
    
    // MARK: UICollectionViewDataSource
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return datas.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "ImageCell", for: indexPath as IndexPath) as! CollectionViewCell
        
        cell.data = self.datas[indexPath.row]
        
        return cell
    }
    
    
    // MARK: - Navigation
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController and pass the selected object to the new view controller.
        if segue.identifier == "ShowDetailView" {
//            if let indexPath = self.aCollectionView?.indexPath(for: sender as! UICollectionViewCell) {
//                let detailVC = segue.destination as! DetailViewController
//                detailVC.imageView.image = self.datas[indexPath.row]
//            }
            
        }
    }
    
    
}
