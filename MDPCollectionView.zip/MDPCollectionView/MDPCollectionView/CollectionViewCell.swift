//
//  CollectionViewCell.swift
//  MDPCollectionView
//
//  Created by Andre' Coward on 8/6/17.
//  Copyright © 2017 Andre' Coward. All rights reserved.
//

import UIKit
import Haneke

class CollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var imageView: UIImageView!
    
    var data:JSON? {
        didSet{
            self.setupData()
        }
    }
    
    func setupData() {
        if let urlString = self.data?["images"]["standard_resolution"]["url"]{
            let url = NSURL(string: urlString.stringValue)
            self.imageView.hnk_setImageFromURL(url! as URL)
        }
    }
}
